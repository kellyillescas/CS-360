package com.zybooks.kellyillescasprojecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.EditText;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private ArrayList<ProductModel> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView iconAdd = findViewById(R.id.add_new_item);
        iconAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open a dialog or activity to add a new item
                showAddItemDialog();
            }
        });

        recyclerView = findViewById(R.id.recyclerView);
        productList = ProductModel.getDummyProducts(); // Load initial data
        adapter = new ProductAdapter(this, productList);

        // Layout manager for the RecyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Set the adapter to the RecyclerView
        recyclerView.setAdapter(adapter);
    }

    // Method to add a new item
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        // Inflate the dialog layout from dialog_add_item.xml
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        final EditText editTextItemName = dialogView.findViewById(R.id.editTextItemName);
        final EditText editTextItemQuantity = dialogView.findViewById(R.id.editTextItemQuantity);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Get the item name and quantity entered by the user
                String itemName = editTextItemName.getText().toString();
                String quantityStr = editTextItemQuantity.getText().toString();

                if (!itemName.isEmpty() && !quantityStr.isEmpty()) {
                    // Convert the quantity to an integer
                    int quantity = Integer.parseInt(quantityStr);

                    // Create a new ProductModel instance with the entered data
                    ProductModel newItem = new ProductModel(itemName, R.drawable.chips, quantity);

                    // Add the new item to the productList
                    productList.add(newItem);

                    // Notify the adapter that the dataset has changed
                    adapter.notifyDataSetChanged();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

}