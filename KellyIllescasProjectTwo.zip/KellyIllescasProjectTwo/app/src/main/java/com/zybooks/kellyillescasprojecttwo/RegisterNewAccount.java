package com.zybooks.kellyillescasprojecttwo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextUtils;
import android.content.Intent;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterNewAccount extends AppCompatActivity {
    private EditText nameEditText;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button signUpButton;
    private TextView signupTextView; // Move the declaration here

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_account);

        nameEditText = findViewById(R.id.nameEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        signUpButton = findViewById(R.id.signUpButton);
        signupTextView = findViewById(R.id.signupTextView); // Initialize the TextView here

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered name, username, and password
                String name = nameEditText.getText().toString();
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Perform user registration logic here
                if (isValidRegistrationData(name, username, password)) {
                    long userId = saveUserDataToDatabase(name, username, password);
                    if (userId != -1) {
                        // Registration Successful
                        // Start the LoginActivity or any other desired activity here
                        Intent intent = new Intent(RegisterNewAccount.this, Login.class);
                        startActivity(intent);
                    } else {
                        // Registration failed
                    }
                }
            }
        });

        signupTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // To start the RegisterNewAccount activity when the Sign Up button is clicked
                Intent intent = new Intent(RegisterNewAccount.this, RegisterNewAccount.class);
                startActivity(intent);
            }
        });
    }

    private boolean isValidRegistrationData(String name, String username, String password) {
        // Make sure name, username, and password are not empty
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            return false;
        }

        // Check if username is at least 6 characters long
        if (username.length() <= 6) {
            return false;
        }

        // Check if the password is at least 8 characters long
        if (password.length() <= 8) {
            return false;
        }

        return true;
    }

    // For the RegisterNewAccount activity class
    private long saveUserDataToDatabase(String name, String username, String password) {
        long newRowId = -1;

        // Get an instance of your DatabaseHelper class to access the database
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Get a writable database
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Create a ContentValues object to store the data you want to insert
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("username", username);
        values.put("password", password);

        // Insert the data into the "user" table
        newRowId = db.insert("user", null, values);

        // Close the database to release resources
        db.close();

        return newRowId;
    }
}
