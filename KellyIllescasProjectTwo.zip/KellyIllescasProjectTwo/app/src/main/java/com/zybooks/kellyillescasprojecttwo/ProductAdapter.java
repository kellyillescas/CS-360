package com.zybooks.kellyillescasprojecttwo;

import android.content.Context;
import android.view.LayoutInflater;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    private ArrayList<ProductModel> productModelArrayList;
    private Context context;

    public ProductAdapter(Context context, ArrayList<ProductModel> productModelArrayList) {
        this.context = context;
        this.productModelArrayList = productModelArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_item_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProductModel productModel = productModelArrayList.get(position);

        holder.itemNameTextView.setText(productModel.getProduct_name());
        holder.itemQuantityTextView.setText(String.valueOf(productModel.getProduct_qty()));
        holder.itemImageView.setImageResource(productModel.getImgid());

        // Set an OnClickListener for the entire row
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // To navigate to the inventory_item_fragment and pass the selected item's data
                openInventoryItemFragment(productModel);
            }
        });
    }

    @Override
    public int getItemCount() {
        return productModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemNameTextView;
        TextView itemQuantityTextView;
        ImageView itemImageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.inventory_item_name);
            itemQuantityTextView = itemView.findViewById(R.id.inventory_item_quantity_label);
            itemImageView = itemView.findViewById(R.id.inventory_item_image);
        }
    }

    private void openInventoryItemFragment(ProductModel productModel) {
        // Create a tag for the item name
        String fragmentTag = "item_fragment_" + productModel.getProduct_name();

        // Check if a fragment with the same tag already exists
        FragmentManager fragmentManager = ((AppCompatActivity) context).getSupportFragmentManager();
        Fragment existingFragment = fragmentManager.findFragmentByTag(fragmentTag);

        if (existingFragment == null) {
            // If the fragment doesn't exist, create a new one
            Bundle bundle = new Bundle();
            bundle.putString("productName", productModel.getProduct_name());
            bundle.putInt("productQuantity", productModel.getProduct_qty());

            ItemFragment fragment = new ItemFragment();
            fragment.setArguments(bundle);

            // To replace the fragment
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.fragment_container, fragment, "item_fragment");
            transaction.addToBackStack(null);
            transaction.commit();
        } else {
            // Update the fragment
            if (existingFragment instanceof ItemFragment) {
                ((ItemFragment) existingFragment).updateContent(productModel.getProduct_name(), productModel.getProduct_qty());
            }
        }
    }

}
