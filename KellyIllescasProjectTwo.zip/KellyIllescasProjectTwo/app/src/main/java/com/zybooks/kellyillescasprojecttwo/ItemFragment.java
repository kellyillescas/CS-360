package com.zybooks.kellyillescasprojecttwo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ItemFragment extends Fragment {

    private ImageView itemImage;
    private TextView itemName;
    private TextView itemQuantity;
    private int currentQuantity;

    public ItemFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.inventory_item_fragment, container, false);

        itemName = rootView.findViewById(R.id.item_name_input);
        itemQuantity = rootView.findViewById(R.id.item_qty_input);

        Bundle args = getArguments();
        if (args != null) {
            String productName = args.getString("productName");
            int productQuantity = args.getInt("productQuantity");

            // Populate the views with product details
            itemName.setText(productName);

            currentQuantity = productQuantity;
            itemQuantity.setText(String.valueOf(productQuantity));
        }

        // Add OnClickListeners to decrease or increase product quantity
        rootView.findViewById(R.id.item_qty_decrease).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decreaseQuantity();
            }
        });

        rootView.findViewById(R.id.item_qty_increase).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                increaseQuantity();
            }
        });

        return rootView;
    }

    // Methods to decrease and increase product quantity
    private void decreaseQuantity() {
        if (currentQuantity > 0) {
            currentQuantity--;
            itemQuantity.setText(String.valueOf(currentQuantity));
        } else {
            Toast.makeText(getContext(), "Quantity cannot be less than 0", Toast.LENGTH_SHORT).show();
        }
    }

    private void increaseQuantity() {
        currentQuantity++;
        itemQuantity.setText(String.valueOf(currentQuantity));
    }

    // Method to update a fragment's content
    public void updateContent(String productName, int productQuantity) {
        if (itemName != null && itemQuantity != null) {
            itemName.setText(productName);
            itemQuantity.setText(String.valueOf(productQuantity));
        }
    }
}