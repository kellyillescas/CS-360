package com.zybooks.kellyillescasprojecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button submitButton;
    private Button communicationButton;
    private Button cameraButton;
    private UserAccountDAO userAccountDAO;

    // Adding a request code for communication permission
    private static final int COMMUNICATION_PERMISSION_REQUEST_CODE = 1;

    // Adding a request code for camera permission
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);
        Tools.setSystemBarLight(this);
        Tools.setSystemBarColor(this,R.color.white);

        userAccountDAO = new UserAccountDAO(this);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        submitButton = findViewById(R.id.submit_button);
        communicationButton = findViewById(R.id.communication);
        cameraButton = findViewById(R.id.camera);

        // Click event for adding a new account
        TextView signupTextView = findViewById(R.id.signupTextView);
        signupTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This will take the user to the RegisterNewAccount page
                Intent intent = new Intent(Login.this, RegisterNewAccount.class);
                startActivity(intent);
            }
        });

        // Click event for logging the user in
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Check if the user's credentials are valid
                if (userAccountDAO.isValidUser(username, password)) {
                    // Navigate to MainActivity if valid
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    // Display an error message if credentials are not valid
                    Toast.makeText(Login.this, "Login Failed. Invalid credentials.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Click event for the communication button
        communicationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if the communication permission is granted
                if (ContextCompat.checkSelfPermission(Login.this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {
                    // Permission is already granted
                    Toast.makeText(Login.this, "Communication permission is already granted.", Toast.LENGTH_SHORT).show();
                } else {
                    // Permission is not granted, request it from the user
                    ActivityCompat.requestPermissions(
                            Login.this,
                            new String[]{Manifest.permission.RECEIVE_SMS},
                            COMMUNICATION_PERMISSION_REQUEST_CODE
                    );
                }
            }
        });

        // Click event for the camera button
        cameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if the camera permission is granted
                if (ContextCompat.checkSelfPermission(Login.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    // Permission is already granted
                    Toast.makeText(Login.this, "Camera permission is already granted.", Toast.LENGTH_SHORT).show();
                } else {
                    // Permission is not granted, request it from the user
                    ActivityCompat.requestPermissions(
                            Login.this,
                            new String[]{Manifest.permission.CAMERA},
                            CAMERA_PERMISSION_REQUEST_CODE
                    );
                }
            }
        });
    }

    // Handle permission request results
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == COMMUNICATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Text permission granted
                Toast.makeText(Login.this, "Communication permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                // Text permission denied
                Toast.makeText(Login.this, "Communication permission denied.", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Camera permission granted
                Toast.makeText(Login.this, "Camera permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                // Camera permission denied
                Toast.makeText(Login.this, "Camera permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}