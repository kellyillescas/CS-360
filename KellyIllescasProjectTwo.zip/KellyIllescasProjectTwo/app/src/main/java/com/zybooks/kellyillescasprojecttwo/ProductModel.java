package com.zybooks.kellyillescasprojecttwo;

import java.util.ArrayList;

public class ProductModel {
    // string product_name for storing product name
    // and imgid for storing image id.
    private String product_name;
    private int imgid;
    private int product_qty;

    public ProductModel(String product_name, int imgid, int product_qty) {
        this.product_name = product_name;
        this.imgid = imgid;
        this.product_qty = product_qty;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getImgid() {
        return imgid;
    }

    public void setImgid(int imgid) {
        this.imgid = imgid;
    }

    public int getProduct_qty() {
        return product_qty;
    }

    public void setProduct_qty(int product_qty) {
        this.product_qty = product_qty;
    }

    public static ArrayList<ProductModel> getDummyProducts() {

        ArrayList<ProductModel> dummyProducts = new ArrayList<>();

        dummyProducts.add(new ProductModel("Doritos Nacho Cheese", R.drawable.doritos, 12));
        dummyProducts.add(new ProductModel("Cheetos Crunchy", R.drawable.cheetos, 15));
        dummyProducts.add(new ProductModel("Fritos Original", R.drawable.fritos, 22));
        dummyProducts.add(new ProductModel("Tostitos Scoops", R.drawable.tostitos, 18));
        dummyProducts.add(new ProductModel("Ruffles Original", R.drawable.ruffles, 1));
        dummyProducts.add(new ProductModel("Pringles Sour Cream", R.drawable.pringles, 20));

        return dummyProducts;
    }

    public static void addItem(ArrayList<ProductModel> productList, String itemName, int quantity, int imageResourceId) {
        productList.add(new ProductModel(itemName, imageResourceId, quantity));
    }
}
