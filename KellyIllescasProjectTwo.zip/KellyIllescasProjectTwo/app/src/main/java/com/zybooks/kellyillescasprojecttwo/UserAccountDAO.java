package com.zybooks.kellyillescasprojecttwo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserAccountDAO {
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public UserAccountDAO(Login context) {

        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long newRowId = db.insert("user", null, values);
        return newRowId;
    }

    public boolean isValidUser(String username, String password) {
        Cursor cursor = db.query("user", null, "username=? AND password=?", new String[]{username, password}, null, null, null);
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    // To close the database
    public void closeDatabase() {
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
}
