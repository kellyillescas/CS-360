package com.zybooks.kellyillescasprojecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "user_accounts.db";
    private static final int DATABASE_VERSION = 2;

    // SQL statement (needed to be able to create the table)
    private static final String CREATE_TABLE_USER = "CREATE TABLE user " +
            "(_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "name TEXT NOT NULL, " +
            "username TEXT NOT NULL, " +
            "password TEXT NOT NULL);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION + 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the user table
        String CREATE_USER_TABLE = "CREATE TABLE user (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "username TEXT," +
                "password TEXT)";
        db.execSQL(CREATE_TABLE_USER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE user ADD COLUMN name TEXT;");
        }
    }

    // This method will insert user data into the database
    public long insertUserData(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long newRowId = db.insert("user", null, values);
        db.close();
        return newRowId;
    }

    // This method will get user data from the database
    public Cursor getUserData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                "name",
                "username",
                "password"
        };
        Cursor cursor = db.query(
                "user",
                projection,
                null,
                null,
                null,
                null,
                null
        );
        return cursor;
    }
}
